package com.example.movieapp.data.remote.mappers

import com.example.movieapp.data.remote.model.Result
import com.example.movieapp.domain.model.MovieDto

fun List<Result>.toDomainMovieList(): List<MovieDto>{
    return map {
        MovieDto(
            id = it.id,
            imageUrl = """https://image.tmdb.org/t/p/w500/${it.poster_path}""",
            language = it.original_language,
            title = it.original_title,
            overview = it.overview,
            popularity = it.popularity,
            releaseDate = it.release_date
        )
    }

}