package com.example.movieapp.domain.usecase

import com.example.movieapp.domain.repository.MovieListRepository
import javax.inject.Inject

class GetMoviesUseCase @Inject constructor(private val repository: MovieListRepository) {

    operator fun invoke() = repository.getNowPlaying()
}