package com.example.movieapp.domain.model

import android.os.Parcelable

@kotlinx.parcelize.Parcelize
data class MovieDto(
    val id:Int?,
    val imageUrl: String?,
    val language: String?,
    val title: String?,
    val overview: String?,
    val popularity: Double = 0.0,
    val releaseDate: String?
):Parcelable