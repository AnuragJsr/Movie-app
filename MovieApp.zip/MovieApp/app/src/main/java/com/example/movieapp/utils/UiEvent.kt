package com.example.movieapp.utils

sealed class UiEvent {
    data class ShowError(val message: String) : UiEvent()
}