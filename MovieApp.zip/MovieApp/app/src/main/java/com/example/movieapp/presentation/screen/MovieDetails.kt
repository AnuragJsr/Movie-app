package com.example.movieapp.presentation.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.example.movieapp.R
import com.example.movieapp.domain.model.MovieDto


@OptIn(ExperimentalGlideComposeApi::class)
@Composable
fun MovieDetails(movieData: MovieDto) {
    Column {

        GlideImage(
            modifier = Modifier
                .fillMaxWidth()
                .height(500.dp),
            contentScale = ContentScale.Crop,
            contentDescription = "demo",
            model = movieData.imageUrl
        )

        Row(
            modifier = Modifier.padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = movieData.title ?: "", modifier = Modifier.weight(0.5f),
                fontSize = 15.sp,
                fontWeight = FontWeight.Black
            )

            Text(
                text = stringResource(R.string.voting, movieData.popularity),
                fontSize = 15.sp,
                fontWeight = FontWeight.Black
            )
        }

        Text(
            modifier = Modifier.padding(10.dp),
            fontSize = 15.sp,
            fontStyle = FontStyle.Italic,
            text = movieData.overview ?: ""
        )

        Row(
            modifier = Modifier.padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.language, movieData.language?:""), modifier = Modifier.weight(0.5f),
                fontSize = 15.sp,
                fontWeight = FontWeight.Black
            )

            Text(
                text = stringResource(R.string.release_date, movieData.releaseDate?:""),
                fontSize = 15.sp,
                fontWeight = FontWeight.Black
            )
        }

    }
}
