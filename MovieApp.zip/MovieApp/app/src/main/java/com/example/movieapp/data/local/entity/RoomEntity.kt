package com.example.movieapp.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "movies")
data class MovieEntity(
    @PrimaryKey val id: Int,
    val imageUrl: String,
    val language: String,
    val title: String,
    val overview: String,
    val popularity: Double,
    val releaseDate: String
)
