package com.example.movieapp.data.repository

import com.example.movieapp.data.local.dao.MovieDao
import com.example.movieapp.data.local.mapper.toDomain
import com.example.movieapp.data.local.mapper.toEntity
import com.example.movieapp.data.remote.api.MovieApiService
import com.example.movieapp.data.remote.mappers.toDomainMovieList
import com.example.movieapp.domain.model.MovieDto
import com.example.movieapp.domain.repository.MovieListRepository
import com.example.movieapp.utils.ApiResult
import com.example.movieapp.utils.responseWrapper
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject

class MovieListRepositoryImpl @Inject constructor(private val api: MovieApiService,
                                                  private val dao: MovieDao): MovieListRepository {


    override fun getNowPlaying(): Flow<ApiResult<List<MovieDto>>> = flow {
        emit(ApiResult.Loading)

        // Fetch data from API
        when (val result = responseWrapper { api.getAllMovies() }) {
            is ApiResult.Success -> {
                val domainData = result.data.results.toDomainMovieList()
                dao.insertMovie(domainData.toEntity())  // Save data locally
                emit(ApiResult.Success(domainData))   // Emit successful result
            }

            is ApiResult.Error -> {
                // If API call fails, try to fetch from cache
                val cachedData = dao.getAllMovies().toDomain()
                if (cachedData.isNotEmpty()) {
                    emit(ApiResult.Success(cachedData, fromCache = true))  // Fallback to cached data
                } else {
                    emit(ApiResult.Error(code = 503, message = "No Internet and no cached data"))
                }
            }

            else -> Unit  // Handle other cases if necessary
        }
    }
}