package com.example.movieapp.presentation.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.movieapp.data.remote.mappers.toDomainMovieList
import com.example.movieapp.data.remote.model.MovieData
import com.example.movieapp.domain.model.MovieDto
import com.example.movieapp.domain.usecase.GetMoviesUseCase
import com.example.movieapp.utils.ApiResult
import com.example.movieapp.utils.UiEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.scopes.ViewModelScoped
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MoviesViewModel @Inject constructor(private val getMoviesUseCase: GetMoviesUseCase): ViewModel() {

    // Movie list state
    private val _movieList = MutableStateFlow<ApiResult<List<MovieDto>>>(ApiResult.Loading)
    val movieList = _movieList.asStateFlow()

    // Search query state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Error channel to show error messages in UI
    private val _errorChannel:Channel<UiEvent> = Channel()
    val errorChannel = _errorChannel.receiveAsFlow()

    // Filtered movies based on search query

    @OptIn(FlowPreview::class)
    val filteredMovies: StateFlow<List<MovieDto>> = combine(
        _movieList,
        _searchQuery.debounce(300).distinctUntilChanged()
    ) { result, queryRaw ->
        val query = queryRaw.trim().lowercase()

        val allMovies = (result as? ApiResult.Success)?.data.orEmpty()
        if (query.isBlank()) {
            allMovies
        } else {
          allMovies.filter {
                it.title?.startsWith(query, ignoreCase = true) == true
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )



    init {
        fetchMovies()
    }

    // Function to fetch movies from the repository
    fun fetchMovies() {
        viewModelScope.launch(Dispatchers.IO) {
            getMoviesUseCase().collect { result ->
                if(result is ApiResult.Success){
                    _movieList.value = result
                    if (result.fromCache) {
                        _errorChannel.send(UiEvent.ShowError("Movies fetched from DB"))
                    }

                }
                if (result is ApiResult.Error) {
                    _errorChannel.send( UiEvent.ShowError(result.message ?: "An error occurred"))
                }
            }
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

}