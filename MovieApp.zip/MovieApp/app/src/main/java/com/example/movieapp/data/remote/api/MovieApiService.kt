package com.example.movieapp.data.remote.api

import com.example.movieapp.data.remote.model.MovieData
import retrofit2.Response
import retrofit2.http.GET

interface MovieApiService {

    @GET("movie/now_playing")
    suspend fun getAllMovies(): Response<MovieData>
}