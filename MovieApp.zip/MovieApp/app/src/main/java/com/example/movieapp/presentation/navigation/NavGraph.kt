package com.example.movieapp.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.movieapp.domain.model.MovieDto
import com.example.movieapp.presentation.screen.MovieDetails
import com.example.movieapp.presentation.screen.MovieListScreen

@Composable
fun NavGraph(navController: NavHostController){

    NavHost(navController = navController, startDestination = Routes.MOVIE_LIST) {
        composable(Routes.MOVIE_LIST) {
            MovieListScreen(onMovieClick = {
                navController.currentBackStackEntry?.savedStateHandle?.set("movie", it)
                navController.navigate(Routes.MOVIE_DETAIL)
            })
        }
        composable(Routes.MOVIE_DETAIL){ backStackEntry->
            val movie = navController.previousBackStackEntry?.savedStateHandle?.get<MovieDto>("movie")
            movie?.let { MovieDetails(it) }
        }
    }
}