package com.example.movieapp.utils

import org.json.JSONObject
import retrofit2.Response

suspend fun <T> responseWrapper(apiCall: suspend () -> Response<T>): ApiResult<T> {
    return try {
        val response = apiCall()
        if (response.isSuccessful) {
            val body = response.body()
            if (body != null)
                ApiResult.Success(body)
            else
                ApiResult.Error(code = 200, message = "Empty Data")
        }
        else{
            val errorMsg = response.errorBody()?.string()
            val errorJson = JSONObject(errorMsg ?: "{}")
            ApiResult.Error(response.code(),errorJson.optString("status_message", "Unknown error"))

        }
    }catch (e:Exception){
        ApiResult.Error(null, e.localizedMessage ?: "Unknown exception")
    }

}