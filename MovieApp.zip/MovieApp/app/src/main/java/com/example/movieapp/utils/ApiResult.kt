package com.example.movieapp.utils


sealed class ApiResult<out T>{
    data class Success<T>(val data:T,val fromCache:Boolean = false): ApiResult<T>()
    data class Error(val code :Int?,val message: String?) : ApiResult<Nothing>()
    data object Loading : ApiResult<Nothing>()
}