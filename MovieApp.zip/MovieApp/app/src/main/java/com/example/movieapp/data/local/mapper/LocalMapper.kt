package com.example.movieapp.data.local.mapper

import com.example.movieapp.data.local.entity.MovieEntity
import com.example.movieapp.domain.model.MovieDto


fun List<MovieDto>.toEntity(): List<MovieEntity> {
    return map {
        MovieEntity(
            id = it.id ?: 0,
            imageUrl = """https://image.tmdb.org/t/p/w500/${it.imageUrl}""",
            language = it.language.orEmpty(),
            title = it.title.orEmpty(),
            overview = it.overview.orEmpty(),
            popularity = it.popularity,
            releaseDate = it.releaseDate.orEmpty()
        )
    }
}

fun List<MovieEntity>.toDomain(): List<MovieDto> {
    return map {
        MovieDto(
            id = it.id,
            title = it.title,
            imageUrl = it.imageUrl,
            language = it.language,
            overview = it.overview,
            popularity = it.popularity,
            releaseDate = it.releaseDate
        )
    }
}
