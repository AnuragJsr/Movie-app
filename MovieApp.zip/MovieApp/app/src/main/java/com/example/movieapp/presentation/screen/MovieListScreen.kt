package com.example.movieapp.presentation.screen

import android.widget.Toast
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.movieapp.R
import com.example.movieapp.domain.model.MovieDto
import com.example.movieapp.presentation.viewmodel.MoviesViewModel
import com.example.movieapp.utils.ApiResult
import com.example.movieapp.utils.UiEvent

@Composable
fun MovieListScreen(
    modifier: Modifier = Modifier,
    onMovieClick: (MovieDto) -> Unit = {},
    isPreview: Boolean = false
) {

    val context = LocalContext.current

    if (isPreview) {
        MovieGrid(getDummyMovies(), modifier, onMovieClick)
        return
    }

    val viewModel: MoviesViewModel = hiltViewModel()
    val movieState by viewModel.movieList.collectAsStateWithLifecycle()
    val filteredMovies by viewModel.filteredMovies.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    // Handle error events (one-time UI events)
    LaunchedEffect(Unit) {
        viewModel.errorChannel.collect { event ->
            when (event) {
                is UiEvent.ShowError -> {
                    Toast.makeText(context, event.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    Column(modifier = modifier.fillMaxSize()) {

        SearchBar(query = searchQuery, onQueryChanged = {
            viewModel.onSearchQueryChanged(it)
        })

        when (movieState) {
            is ApiResult.Loading -> {
                ShimmerGrid()
            }

            is ApiResult.Success -> {
                MovieGrid(filteredMovies, modifier, onMovieClick)
            }

            is ApiResult.Error -> {
                RetrySection(onRetry = { viewModel.fetchMovies() })
            }
        }

    }
}

@Composable
fun RetrySection(onRetry: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("No data available.")
        Button(onClick = onRetry) {
            Text("Retry")
        }
    }
}


@Composable
fun SearchBar(
    query: String,
    onQueryChanged: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        TextField(
            value = query,
            onValueChange = onQueryChanged,
            placeholder = { Text(stringResource(R.string.search_movies)) },
            modifier = Modifier.fillMaxWidth()
        )
    }
}


@Composable
fun MovieGrid(movies: List<MovieDto>, modifier: Modifier = Modifier, onClick: (MovieDto) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalArrangement = Arrangement.spacedBy(1.dp),
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp)
    ) {
        items(movies, key = { it.id ?: 0 }) { movie ->
            MovieCard(movie, onClick)
        }
    }
}

@Composable
fun ShimmerGrid() {
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalArrangement = Arrangement.spacedBy(1.dp),
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp)
    ) {
        items(15) {
            ShimmerItem()
        }
    }
}

@Composable
fun ShimmerItem() {
    val shimmerColors = listOf(
        Color.LightGray.copy(alpha = 0.6f),
        Color.LightGray.copy(alpha = 0.2f),
        Color.LightGray.copy(alpha = 0.6f)
    )

    val transition = rememberInfiniteTransition()
    val translateAnim by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000),
            repeatMode = RepeatMode.Reverse
        )
    )

    val brush = Brush.linearGradient(
        colors = shimmerColors,
        start = Offset(translateAnim, translateAnim),
        end = Offset(translateAnim + 200f, translateAnim + 200f)
    )

    Box(
        modifier = Modifier
            .padding(4.dp)
            .fillMaxWidth()
            .aspectRatio(0.7f)
            .background(brush, RoundedCornerShape(10.dp))
    )
}

@OptIn(ExperimentalGlideComposeApi::class)
@Composable
fun MovieCard(movie: MovieDto, onClick: (MovieDto) -> Unit) {
    Card(
        modifier = Modifier
            .padding(4.dp)
            .fillMaxWidth()
            .aspectRatio(0.7f),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(4.dp),
        onClick = { onClick(movie) }
    ) {
        GlideImage(
            model = movie.imageUrl,
            contentDescription = movie.title,
            contentScale = ContentScale.FillWidth,
            requestBuilderTransform = {
                it.diskCacheStrategy(DiskCacheStrategy.ALL)
                    .skipMemoryCache(false)

            }
        )
    }

}

fun getDummyMovies(): List<MovieDto> = List(16) {
    MovieDto(
        id = 0,
        imageUrl = null,
        language = "en",
        title = "Movie $it",
        overview = "This is a dummy movie description",
        popularity = 100.0 + it,
        releaseDate = "2025-0${it + 1}-01"
    )
}

@Preview(showBackground = true)
@Composable
fun MovieListPreview() {
    MovieListScreen(isPreview = true)
}
